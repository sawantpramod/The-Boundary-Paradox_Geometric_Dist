import pandas as pd
from common import OUTPUT_TABLES

def main():
    # Load the innings-level dataset (from Step 2)
    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")

    # ---- Check required columns ----
    required_cols = ['first_wicket_phase', 'first_boundary_phase']
    missing = [c for c in required_cols if c not in innings_df.columns]
    if missing:
        raise ValueError(
            f"The file innings_survival_dataset.csv is missing columns: {missing}.\n"
            "Please ensure you have run 02_build_innings.py successfully before this script."
        )
    # ---------------------------------

    # Define phase order
    phases = ['power_play', 'middle_over', 'death_over']

    # ---- Compute counts for first wicket phase ----
    wicket_counts = innings_df['first_wicket_phase'].value_counts()
    n_wicket_matched = wicket_counts.sum()  # number of innings with a wicket (all should have one)
    wicket_pct = (wicket_counts / n_wicket_matched * 100).reindex(phases, fill_value=0.0)
    wicket_counts = wicket_counts.reindex(phases, fill_value=0)

    # ---- Compute counts for first boundary phase ----
    boundary_counts = innings_df['first_boundary_phase'].value_counts()
    n_boundary_matched = boundary_counts.sum()
    boundary_pct = (boundary_counts / n_boundary_matched * 100).reindex(phases, fill_value=0.0)
    boundary_counts = boundary_counts.reindex(phases, fill_value=0)

    # ---- Build formatted table ----
    def fmt(pct, count, total):
        return f"{pct:.1f}% ({count}/{total})"

    result_table = pd.DataFrame({
        'Event': ['First wicket', 'First boundary'],
        'Powerplay': [
            fmt(wicket_pct['power_play'], wicket_counts['power_play'], n_wicket_matched),
            fmt(boundary_pct['power_play'], boundary_counts['power_play'], n_boundary_matched)
        ],
        'Middle overs': [
            fmt(wicket_pct['middle_over'], wicket_counts['middle_over'], n_wicket_matched),
            fmt(boundary_pct['middle_over'], boundary_counts['middle_over'], n_boundary_matched)
        ],
        'Death overs': [
            fmt(wicket_pct['death_over'], wicket_counts['death_over'], n_wicket_matched),
            fmt(boundary_pct['death_over'], boundary_counts['death_over'], n_boundary_matched)
        ]
    })

    print("=== FIRST EVENT PHASE DISTRIBUTION ===")
    print(result_table.to_string(index=False))

    # Save the formatted table
    result_table.to_csv(OUTPUT_TABLES / "first_event_phase_summary.csv", index=False)

    # Also save raw percentages (without counts) for reference
    raw_pct = pd.DataFrame({
        'phase': phases,
        'first_wicket_pct': wicket_pct.values,
        'first_boundary_pct': boundary_pct.values
    })
    raw_pct.to_csv(OUTPUT_TABLES / "first_event_phase_raw.csv", index=False)

if __name__ == "__main__":
    main()