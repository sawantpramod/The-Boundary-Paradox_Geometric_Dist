#!/usr/bin/env python
"""
Stratification Analysis for Memoryless Property

This script tests whether the memoryless property holds within homogeneous
subgroups of innings, stratified by boundary rate (scoring rate).

CORRECTED VERSION:
- Added Cramér's V effect size calculation
- Added effect size interpretation
- Added statistical power caveat
- Added circularity disclosure
- Fixed Unicode encoding issues for Windows compatibility

The hypothesis: If innings are grouped by their overall boundary rate,
does the geometric (memoryless) pattern still hold within each group?

Usage:
    python 09_stratification_analysis.py
    python 09_stratification_analysis.py --n-groups 3
    python 09_stratification_analysis.py --n-groups 4 --output stratification_results.csv
"""

import argparse
import numpy as np
import pandas as pd
from scipy.stats import chi2
from pathlib import Path
import sys
import warnings
from collections import defaultdict

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Try to import common, but provide fallback paths
try:
    from common import OUTPUT_TABLES, OUTPUT_FIGURES, load_data
except ImportError:
    # Fallback: define paths relative to current directory
    OUTPUT_TABLES = Path("tables")
    OUTPUT_FIGURES = Path("figures")
    print(f"Warning: Using fallback output paths: {OUTPUT_TABLES}")

# Create output directories if they don't exist
OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)
OUTPUT_FIGURES.mkdir(parents=True, exist_ok=True)


def load_innings_data(filepath=None):
    """Load the innings survival dataset."""
    if filepath is None:
        filepath = OUTPUT_TABLES / "innings_survival_dataset.csv"
    
    try:
        df = pd.read_csv(filepath)
        print(f"[OK] Loaded innings data: {len(df)} innings")
        return df
    except FileNotFoundError:
        print(f"[ERROR] File not found: {filepath}")
        print("Please ensure the data has been prepared first.")
        sys.exit(1)


def load_ball_by_ball_data():
    """Load the ball-by-ball data for detailed analysis."""
    try:
        df = pd.read_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv")
        print(f"[OK] Loaded ball-by-ball data: {len(df)} deliveries")
        return df
    except FileNotFoundError:
        print("[ERROR] Ball-by-ball data not found.")
        sys.exit(1)


def compute_innings_boundary_rates(innings_df, ball_data):
    """
    Compute boundary rate for each innings from ball-by-ball data.
    
    Args:
        innings_df: DataFrame with innings identifiers
        ball_data: DataFrame with ball-by-ball data
    
    Returns:
        Series with boundary rates for each innings
    """
    # Group ball data by innings
    innings_balls = ball_data.groupby(['match_id', 'innings_no'])
    
    rates = {}
    for (match_id, innings_no), group in innings_balls:
        total_legal = len(group)
        boundaries = group['is_boundary'].sum() if 'is_boundary' in group.columns else 0
        
        # Find if this innings exists in innings_df
        mask = (innings_df['match_id'] == match_id) & (innings_df['innings_no'] == innings_no)
        if mask.any() and total_legal > 0:
            idx = innings_df[mask].index[0]
            rates[idx] = boundaries / total_legal
    
    # Create Series aligned with innings_df
    rate_series = pd.Series(index=innings_df.index, dtype=float)
    for idx, rate in rates.items():
        rate_series[idx] = rate
    
    # Fill any missing values (shouldn't happen)
    rate_series = rate_series.fillna(0)
    
    return rate_series


def compute_group_rates(innings_df, group_mask, ball_data):
    """
    Compute boundary rate for a specific group of innings.
    """
    # Get the innings in this group
    group_innings = innings_df[group_mask]
    
    if len(group_innings) == 0:
        return 0.0
    
    # Get ball data for these innings
    merged = group_innings.merge(
        ball_data, 
        on=['match_id', 'innings_no'], 
        how='left'
    )
    
    total_legal = len(merged)
    if 'is_boundary' in merged.columns:
        boundaries = merged['is_boundary'].sum()
    else:
        # Fallback: count from innings data
        boundaries = group_innings['boundary_count'].sum() if 'boundary_count' in group_innings.columns else 0
    
    return boundaries / total_legal if total_legal > 0 else 0.0


def get_observed_waits(innings_df, group_mask, event_type='boundary'):
    """
    Get observed wait times for a specific group.
    """
    group = innings_df[group_mask]
    
    if event_type == 'boundary':
        waits = group[group['first_boundary_event'] == 1]['first_boundary_attempt'].dropna().values
    else:
        waits = group[group['first_wicket_event'] == 1]['first_wicket_attempt'].dropna().values
    
    return waits


def cramers_v(observed_counts, expected_counts, n_total):
    """
    Calculate Cramér's V effect size for chi-square test.
    
    V = sqrt(χ² / (n * min(r-1, c-1)))
    
    For goodness-of-fit tests, min(r-1, c-1) = 1 (since c=1 for goodness-of-fit)
    """
    chi2 = np.sum((np.array(observed_counts) - np.array(expected_counts))**2 / np.array(expected_counts))
    # For goodness-of-fit, min(r-1, c-1) = 1
    df_effect = 1
    v = np.sqrt(chi2 / (n_total * df_effect))
    return v


def interpret_effect_size(v):
    """Interpret Cramér's V effect size."""
    if v < 0.05:
        return "negligible"
    elif v < 0.10:
        return "very small"
    elif v < 0.20:
        return "small"
    elif v < 0.30:
        return "small-medium"
    elif v < 0.40:
        return "medium"
    elif v < 0.50:
        return "medium-large"
    else:
        return "large"


def get_effect_size_description(v):
    """Get a detailed description of the effect size."""
    if v < 0.05:
        return "negligible - practically no deviation"
    elif v < 0.10:
        return "very small - practically insignificant"
    elif v < 0.20:
        return "small - modest deviation"
    elif v < 0.30:
        return "small-medium - noticeable but not strong"
    elif v < 0.40:
        return "medium - moderate deviation"
    else:
        return "large - substantial deviation"


def run_chi_square_test(observed_waits, p_hat, event_name="Group"):
    """
    Run chi-square goodness-of-fit test for geometric distribution.
    Returns results including Cramér's V effect size.
    """
    n = len(observed_waits)
    if n < 10:
        return {
            'chi2': np.nan,
            'p_value': np.nan,
            'df': 0,
            'n': n,
            'cramers_v': np.nan,
            'effect_size': 'Insufficient data',
            'effect_size_detail': 'Too few observations for reliable test',
            'warning': 'Too few observations for reliable test'
        }
    
    max_ball = max(observed_waits)
    
    # Dynamically find cutoff where expected count drops below 5
    cutoff = 1
    while cutoff <= max_ball:
        expected_count = n * ((1 - p_hat)**(cutoff - 1) * p_hat)
        if expected_count < 5:
            break
        cutoff += 1
    
    cutoff = max(4, cutoff)
    
    # Create bins
    bins = list(range(1, cutoff)) + [cutoff]
    observed_counts = []
    
    for i in range(len(bins) - 1):
        count = sum((observed_waits >= bins[i]) & (observed_waits < bins[i+1]))
        observed_counts.append(count)
    count = sum(observed_waits >= bins[-1])
    observed_counts.append(count)
    
    # Expected counts under Geometric distribution
    expected_counts = []
    for i in range(len(bins) - 1):
        if bins[i] == 1:
            prob = (1 - (1 - p_hat)**(bins[i+1] - 1))
        else:
            prob = ((1 - p_hat)**(bins[i] - 1) - (1 - p_hat)**(bins[i+1] - 1))
        expected_counts.append(n * prob)
    prob = (1 - p_hat)**(cutoff - 1)
    expected_counts.append(n * prob)
    
    # Calculate Chi-Square
    chi2_stat = np.sum((np.array(observed_counts) - np.array(expected_counts))**2 / np.array(expected_counts))
    df = len(bins) - 2
    p_val = 1 - chi2.cdf(chi2_stat, df)
    
    # Calculate Cramér's V
    v = cramers_v(observed_counts, expected_counts, n)
    effect_size = interpret_effect_size(v)
    effect_detail = get_effect_size_description(v)
    
    return {
        'chi2': chi2_stat,
        'p_value': p_val,
        'df': df,
        'n': n,
        'cutoff': cutoff,
        'cramers_v': v,
        'effect_size': effect_size,
        'effect_size_detail': effect_detail,
        'warning': None
    }


def stratify_innings(innings_df, ball_data, n_groups=3, event_type='boundary'):
    """
    Split innings by boundary rate into n_groups and test memorylessness within each.
    
    Args:
        innings_df: DataFrame with innings-level data
        ball_data: DataFrame with ball-by-ball data
        n_groups: Number of groups to split into (terciles = 3, quartiles = 4, etc.)
        event_type: 'boundary' or 'wicket'
    
    Returns:
        Dictionary with results for each group
    """
    print(f"\n{'='*70}")
    print(f"STRATIFICATION ANALYSIS: {event_type.upper()}S")
    print(f"Splitting into {n_groups} groups based on boundary rate")
    print(f"{'='*70}\n")
    
    # Compute boundary rates for each innings
    boundary_rates = compute_innings_boundary_rates(innings_df, ball_data)
    
    # Remove innings with no data
    valid_mask = ~boundary_rates.isna()
    valid_rates = boundary_rates[valid_mask]
    valid_innings = innings_df[valid_mask]
    
    print(f"Total innings with rate data: {len(valid_innings)}")
    print(f"Boundary rate range: [{valid_rates.min():.4f}, {valid_rates.max():.4f}]")
    print(f"Mean boundary rate: {valid_rates.mean():.4f}")
    print(f"Median boundary rate: {valid_rates.median():.4f}\n")
    
    # Sort by rate and split into groups
    sorted_indices = valid_rates.sort_values().index
    group_size = len(sorted_indices) // n_groups
    
    groups = []
    group_labels = []
    
    for i in range(n_groups):
        start = i * group_size
        if i == n_groups - 1:
            end = len(sorted_indices)
        else:
            end = start + group_size
        
        group_indices = sorted_indices[start:end]
        group_rates = valid_rates.loc[group_indices]
        
        groups.append(group_indices)
        
        # Create descriptive label
        if n_groups == 3:
            labels = ['Low', 'Middle', 'High']
            group_labels.append(f"{labels[i]} rate")
        else:
            group_labels.append(f"Group {i+1}")
    
    # Analyze each group
    results = {}
    all_results = []
    
    for i, (group_indices, label) in enumerate(zip(groups, group_labels)):
        print(f"\n--- {label} Group (n={len(group_indices)}) ---")
        
        # Get group-specific boundary rate
        group_mask = valid_innings.index.isin(group_indices)
        group_rate = compute_group_rates(valid_innings, group_mask, ball_data)
        print(f"  Group boundary rate: {group_rate:.4f}")
        
        # Get observed waits
        observed_waits = get_observed_waits(valid_innings, group_mask, event_type)
        
        if len(observed_waits) == 0:
            print(f"  No observed {event_type}s in this group")
            results[label] = {
                'group': label,
                'n_innings': len(group_indices),
                'boundary_rate': group_rate,
                'n_observed_events': 0,
                'chi2': np.nan,
                'p_value': np.nan,
                'df': 0,
                'cramers_v': np.nan,
                'effect_size': 'N/A',
                'effect_size_detail': 'No events observed',
                'is_geometric': None,
                'warning': 'No events observed'
            }
            all_results.append(results[label])
            continue
        
        # Run chi-square test with group-specific rate
        test_result = run_chi_square_test(observed_waits, group_rate, f"{label} {event_type}s")
        
        # Store results
        result = {
            'group': label,
            'n_innings': len(group_indices),
            'boundary_rate': group_rate,
            'n_observed_events': len(observed_waits),
            'chi2': test_result['chi2'],
            'p_value': test_result['p_value'],
            'df': test_result['df'],
            'cramers_v': test_result['cramers_v'],
            'effect_size': test_result['effect_size'],
            'effect_size_detail': test_result['effect_size_detail'],
            'is_geometric': test_result['p_value'] > 0.05 if not np.isnan(test_result['p_value']) else None,
            'warning': test_result.get('warning', None)
        }
        results[label] = result
        all_results.append(result)
        
        # Print summary
        print(f"  Observed {event_type}s: {len(observed_waits)}")
        if not np.isnan(test_result['chi2']):
            print(f"  Chi-square: {test_result['chi2']:.4f}")
            print(f"  p-value: {test_result['p_value']:.4f}")
            print(f"  Cramér's V: {test_result['cramers_v']:.4f} ({test_result['effect_size']})")
            print(f"  Geometric pattern: {'YES' if test_result['p_value'] > 0.05 else ' NO'}")
        else:
            print(f"  {test_result.get('warning', 'Test could not be performed')}")
    
    # Overall summary
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    
    results_df = pd.DataFrame(all_results)
    
    if len(results_df) > 0:
        print("\n", results_df[['group', 'n_innings', 'boundary_rate', 'p_value', 'cramers_v', 'effect_size', 'is_geometric']].to_string(index=False))
        
        geometric_groups = results_df[results_df['is_geometric'] == True]
        n_geometric = len(geometric_groups)
        print(f"\nGroups showing geometric pattern: {n_geometric}/{len(results_df)}")
    else:
        print("No results to display.")
    
    # Print power caveat
    print("\n" + "-"*70)
    print("STATISTICAL POWER CAVEAT")
    print("-"*70)
    print("The chi-square tests within each group have only 1 degree of freedom")
    print("(compared to 6 in the pooled test), with roughly one-third the sample size.")
    print("Tests with this level of power will fail to reject the null unless the")
    print("effect is quite large.")
    print("\nThe 'not rejected' finding should be read as:")
    print("  'The data are consistent with the geometric model within groups,'")
    print("  NOT as definitive proof of geometric behavior.")
    
    # Print circularity caveat
    print("\n" + "-"*70)
    print("CIRCULARITY CAVEAT")
    print("-"*70)
    print("The stratification variable - each innings' own realized boundary rate -")
    print("is partly determined by the same events (including the first boundary itself)")
    print("that the outcome variable is built from.")
    print("\nAn innings that gets an early boundary mechanically nudges its own 'rate'")
    print("upward, which could bias groups toward looking more internally consistent")
    print("than an independent proxy (ground, opposition attack, team aggression profile)")
    print("would.")
    print("\nA stronger test would use pre-match covariates rather than post-hoc realized rates.")
    
    return results, results_df


def save_results(results_df, filename="stratification_results.csv"):
    """Save stratification results to CSV."""
    if len(results_df) > 0:
        filepath = OUTPUT_TABLES / filename
        results_df.to_csv(filepath, index=False)
        print(f"\n[OK] Results saved to: {filepath}")
    else:
        print("\n[WARNING] No results to save.")


def create_summary_table(innings_df, results_df):
    """
    Create a comprehensive summary table for the article.
    """
    summary = {
        'metric': [],
        'value': []
    }
    
    # Overall statistics
    summary['metric'].append('Total innings')
    summary['value'].append(len(innings_df))
    
    if 'boundary_rate' in innings_df.columns:
        summary['metric'].append('Boundary rate (mean)')
        summary['value'].append(f"{innings_df['boundary_rate'].mean():.4f}")
    
    # Group statistics
    if len(results_df) > 0:
        for _, row in results_df.iterrows():
            summary['metric'].append(f"{row['group']} group - n")
            summary['value'].append(row['n_innings'])
            
            summary['metric'].append(f"{row['group']} group - rate")
            summary['value'].append(f"{row['boundary_rate']:.4f}")
            
            summary['metric'].append(f"{row['group']} group - chi-square")
            if not np.isnan(row['chi2']):
                summary['value'].append(f"{row['chi2']:.4f}")
            else:
                summary['value'].append('N/A')
            
            summary['metric'].append(f"{row['group']} group - p-value")
            if not np.isnan(row['p_value']):
                summary['value'].append(f"{row['p_value']:.4f}")
            else:
                summary['value'].append('N/A')
            
            summary['metric'].append(f"{row['group']} group - Cramers V")
            if not np.isnan(row['cramers_v']):
                summary['value'].append(f"{row['cramers_v']:.4f}")
            else:
                summary['value'].append('N/A')
            
            summary['metric'].append(f"{row['group']} group - effect size")
            summary['value'].append(row['effect_size'])
            
            summary['metric'].append(f"{row['group']} group - geometric?")
            if row['is_geometric'] is None:
                summary['value'].append('N/A')
            elif row['is_geometric']:
                summary['value'].append('Yes (consistent)')
            else:
                summary['value'].append('No')
    
    return pd.DataFrame(summary)


def main():
    """Main entry point for command-line execution."""
    parser = argparse.ArgumentParser(
        description="Stratification Analysis for Memoryless Property",
        epilog="""
Example:
  python 09_stratification_analysis.py --n-groups 3
  python 09_stratification_analysis.py --n-groups 4 --event wicket
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "--n-groups",
        type=int,
        default=3,
        choices=[2, 3, 4, 5],
        help="Number of groups to split into (default: 3 for terciles)"
    )
    parser.add_argument(
        "--event",
        type=str,
        default="boundary",
        choices=["boundary", "wicket"],
        help="Event type to analyze (default: boundary)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output filename for results CSV (default: stratification_{event}_results.csv)"
    )
    
    args = parser.parse_args()
    
    # Set output filename
    if args.output is None:
        args.output = f"stratification_{args.event}_results.csv"
    
    # Load data
    innings_df = load_innings_data()
    ball_data = load_ball_by_ball_data()
    
    # Add boundary rate to innings_df for reference
    boundary_rates = compute_innings_boundary_rates(innings_df, ball_data)
    innings_df['boundary_rate'] = boundary_rates
    
    # Run stratification analysis
    results, results_df = stratify_innings(
        innings_df, 
        ball_data, 
        n_groups=args.n_groups,
        event_type=args.event
    )
    
    # Save results
    save_results(results_df, args.output)
    
    # Create summary table
    summary_df = create_summary_table(innings_df, results_df)
    if len(summary_df) > 0:
        summary_path = OUTPUT_TABLES / f"stratification_summary_{args.event}.csv"
        summary_df.to_csv(summary_path, index=False)
        print(f"\n[OK] Summary saved to: {summary_path}")
    
    # Print conclusion
    print("\n" + "="*70)
    print("CONCLUSION")
    print("="*70)
    
    if len(results_df) > 0:
        geometric_count = results_df['is_geometric'].sum() if 'is_geometric' in results_df.columns else 0
        total_groups = len(results_df)
        
        # Filter out None values for accurate counting
        valid_results = results_df[results_df['is_geometric'].notna()]
        if len(valid_results) > 0:
            geometric_count_valid = valid_results['is_geometric'].sum()
            total_valid = len(valid_results)
            
            if geometric_count_valid == total_valid:
                print(f"[OK] All {total_valid} groups show geometric pattern.")
                print("-> The memoryless property holds even within homogeneous subgroups.")
                print("-> This supports the geometric model as a valid description of boundary timing.")
                print("\n HOWEVER: This should be read as 'consistent with geometric'")
                print("   not as definitive proof. The tests have limited statistical power")
                print("   and the grouping variable is subject to circularity concerns.")
            elif geometric_count_valid == 0:
                print(f"[FAIL] None of the {total_valid} groups show geometric pattern.")
                print("-> The memoryless property fails even within homogeneous subgroups.")
                print("-> This suggests fundamental non-geometric behavior.")
            else:
                print(f"[WARNING] {geometric_count_valid}/{total_valid} groups show geometric pattern.")
                print("-> Results are mixed - pattern may depend on scoring rate.")
                print("-> Suggests the failure of memorylessness may be driven by heterogeneity.")
        else:
            print("[WARNING] Insufficient data to draw conclusions.")
    else:
        print("[WARNING] No results to analyze.")
    
    print("\nInterpretation for article:")
    print("  - If all groups show geometric pattern: The aggregate non-geometric")
    print("    result may be driven by heterogeneity between innings.")
    print("  - If groups show mixed results: Scoring rate may moderate")
    print("    the memorylessness property.")
    print("  - If no groups show geometric pattern: The memorylessness")
    print("    failure is fundamental and not just an aggregation artifact.")
    print("\n" + "="*70)


if __name__ == "__main__":
    main()