import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter
from common import OUTPUT_TABLES

def conditional_survival(kmf, m, n):
    # Use .values[0] as in the notebook
    S_m = kmf.survival_function_at_times(m).values[0]
    S_mn = kmf.survival_function_at_times(m + n).values[0]
    return np.nan if S_m <= 0 else S_mn / S_m

def run_test(innings_df, duration_col, event_col, event_name, ms, ns):
    kmf = KaplanMeierFitter()
    kmf.fit(innings_df[duration_col], innings_df[event_col], label=event_name)
    rows = []
    for m in ms:
        for n in ns:
            conditional = conditional_survival(kmf, m, n)
            # Use .values[0] for unconditional survival
            unconditional = float(kmf.survival_function_at_times(n).values[0])
            rows.append({
                "event": event_name,
                "m": m,
                "n": n,
                "conditional_survival_S_m+n_over_S_m": conditional,
                "unconditional_survival_S_n": unconditional,
                "difference": conditional - unconditional
            })
    return pd.DataFrame(rows)

def main():
    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")
    result = pd.concat([
        run_test(innings_df, "first_wicket_attempt", "first_wicket_event", "First wicket", [5,10,15], [5,10]),
        run_test(innings_df, "first_boundary_attempt", "first_boundary_event", "First boundary", [2,5,10], [2,5])
    ], ignore_index=True)
    result.to_csv(OUTPUT_TABLES / "memoryless_comparison.csv", index=False)
    print("=== MEMORYLESS-PROPERTY DIAGNOSTIC ===")
    print(result.to_string(index=False))
    print("\nFor a geometric process, S(m+n)/S(m) = S(n). This is a diagnostic, not a formal hypothesis test.")

if __name__ == "__main__":
    main()