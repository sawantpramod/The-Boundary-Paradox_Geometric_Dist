import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter
from scipy.stats import chisquare, chi2
from common import OUTPUT_TABLES

# === FIX 1: Load phase-specific boundary rate ===
def load_phase_rates():
    """Load phase-specific rates from phase analysis"""
    try:
        # Try to read the phase analysis output CSV
        phase_df = pd.read_csv(OUTPUT_TABLES / "phase_probabilities.csv")
        boundary_rate = phase_df[phase_df['phase'] == 'power_play']['p_boundary'].iloc[0]
        return boundary_rate
    except (FileNotFoundError, KeyError, IndexError):
        # Fallback: compute from raw data directly
        try:
            legal_df = pd.read_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv")
            powerplay_deliveries = legal_df[legal_df['overs_category'] == 'power_play']
            boundaries = powerplay_deliveries[powerplay_deliveries['is_boundary'] == True]
            boundary_rate = len(boundaries) / len(powerplay_deliveries)
            return boundary_rate
        except:
            # Ultimate fallback: use the previously hardcoded value
            print("WARNING: Could not load phase rates. Using fallback value 0.268748")
            return 0.268748


def get_observed_counts(innings_data, event_type):
    """Extract observed wait time counts for chi-square test"""
    if event_type == 'boundary':
        observed_waits = innings_data[innings_data['first_boundary_event'] == 1]['first_boundary_attempt'].dropna().values
    else:
        observed_waits = innings_data[innings_data['first_wicket_event'] == 1]['first_wicket_attempt'].dropna().values
    return observed_waits


def conditional_survival(kmf, m, n):
    # Use .values[0] as in the notebook
    S_m = kmf.survival_function_at_times(m).values[0]
    S_mn = kmf.survival_function_at_times(m + n).values[0]
    return np.nan if S_m <= 0 else S_mn / S_m


def run_test(innings_df, duration_col, event_col, event_name, ms, ns):
    kmf = KaplanMeierFitter()
    kmf.fit(innings_df[duration_col], innings_df[event_col], label=event_name)
    rows = []
    for m in ms:
        for n in ns:
            conditional = conditional_survival(kmf, m, n)
            # Use .values[0] for unconditional survival
            unconditional = float(kmf.survival_function_at_times(n).values[0])
            rows.append({
                "event": event_name,
                "m": m,
                "n": n,
                "conditional_survival_S_m+n_over_S_m": conditional,
                "unconditional_survival_S_n": unconditional,
                "difference": conditional - unconditional
            })
    return pd.DataFrame(rows)


def run_chi_square_test(observed_waits, p_hat, event_name):
    """Correct discrete Goodness-of-Fit test for Geometric distribution."""
    n = len(observed_waits)
    max_ball = max(observed_waits)
    
    # Dynamically find a cutoff where expected count drops below 5
    cutoff = 1
    while cutoff <= max_ball:
        expected_count = n * ((1 - p_hat)**(cutoff - 1) * p_hat)
        if expected_count < 5:
            break
        cutoff += 1
    
    # Ensure we have at least a few bins; force cutoff to at least 4
    cutoff = max(4, cutoff)
    
    # Create bins: 1, 2, ..., cutoff-1, cutoff+
    bins = list(range(1, cutoff)) + [cutoff]
    observed_counts = []
    
    for i in range(len(bins) - 1):
        count = sum((observed_waits >= bins[i]) & (observed_waits < bins[i+1]))
        observed_counts.append(count)
    # Last bin: >= cutoff
    count = sum(observed_waits >= bins[-1])
    observed_counts.append(count)
    
    # Expected counts under Geometric distribution
    expected_counts = []
    for i in range(len(bins) - 1):
        if bins[i] == 1:
            prob = (1 - (1 - p_hat)**(bins[i+1] - 1))
        else:
            prob = ((1 - p_hat)**(bins[i] - 1) - (1 - p_hat)**(bins[i+1] - 1))
        expected_counts.append(n * prob)
    # Last bin: P(X >= cutoff)
    prob = (1 - p_hat)**(cutoff - 1)
    expected_counts.append(n * prob)
    
    # Calculate Chi-Square statistic
    chi2_stat = np.sum((np.array(observed_counts) - np.array(expected_counts))**2 / np.array(expected_counts))
    # Degrees of freedom: bins - 1 - 1 (estimated parameter p)
    df = len(bins) - 2
    p_val = 1 - chi2.cdf(chi2_stat, df)
    
    print(f"\n{event_name}:")
    print(f"  - Number of innings: {n}")
    print(f"  - Chi-Square Statistic: {chi2_stat:.4f}")
    print(f"  - Degrees of Freedom: {df}")
    print(f"  - p-value: {p_val:.4f}")
    print(f"  - Rate used: {p_hat:.6f}")
    return p_val


def main():
    # Load the data
    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")
    
    # ============================================
    # PART 1: MEMORYLESS PROPERTY DIAGNOSTIC
    # ============================================
    result = pd.concat([
        run_test(innings_df, "first_wicket_attempt", "first_wicket_event", "First wicket", [5,10,15], [5,10]),
        run_test(innings_df, "first_boundary_attempt", "first_boundary_event", "First boundary", [2,5,10], [2,5])
    ], ignore_index=True)
    result.to_csv(OUTPUT_TABLES / "memoryless_comparison.csv", index=False)
    
    print("=== MEMORYLESS-PROPERTY DIAGNOSTIC ===")
    print(result.to_string(index=False))
    print("\nFor a geometric process, S(m+n)/S(m) = S(n). This is a diagnostic, not a formal hypothesis test.")
    
    # ============================================
    # PART 2: FORMAL GOODNESS-OF-FIT TEST (DISCRETE)
    # ============================================
    print("\n" + "="*60)
    print("CHI-SQUARE GOODNESS-OF-FIT TEST (DISCRETE)")
    print("="*60)
    print("NOTE: KS test is NOT used here because wait-times are discrete.")
    print("      Chi-Square is the correct test for discrete distributions.\n")
    
    # Extract observed wait times
    observed_boundary_waits = innings_df[innings_df['first_boundary_event'] == 1]['first_boundary_attempt'].dropna().values
    observed_wicket_waits = innings_df[innings_df['first_wicket_event'] == 1]['first_wicket_attempt'].dropna().values
    
    # === FIX: Use correct phase-specific rate for boundaries ===
    # For wickets: pooled rate is defensible (spans all phases)
    # For boundaries: use powerplay rate (0.268748 from 06_phase_analysis.py)
    BOUNDARY_RATE = load_phase_rates()
    
    # Wicket rate: pooled rate (defensible)
    # Compute from data
    legal_df = pd.read_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv")
    all_deliveries = legal_df[legal_df['is_wicket'].isin([True, False])]
    total_legal = len(legal_df)
    total_wickets = legal_df['is_wicket'].sum()
    WICKET_RATE = total_wickets / total_legal
    
    print(f"Using BOUNDARY_RATE = {BOUNDARY_RATE:.6f} (powerplay phase-specific rate)")
    print(f"Using WICKET_RATE = {WICKET_RATE:.6f} (pooled rate, spans all phases)\n")
    
    # Run the correct discrete test
    p_boundary = run_chi_square_test(observed_boundary_waits, BOUNDARY_RATE, "BOUNDARIES")
    p_wicket = run_chi_square_test(observed_wicket_waits, WICKET_RATE, "WICKETS")
    
    # ============================================
    # PART 3: INTERPRETATION
    # ============================================
    print("\n" + "="*60)
    print("INTERPRETATION")
    print("="*60)
    
    print("\nBOUNDARIES:")
    if p_boundary < 0.05:
        print(f"  * p = {p_boundary:.4f} < 0.05 -> Statistically significant deviation from geometric distribution.")
        print("  -> The memoryless property does NOT hold for boundaries (at aggregate level).")
        print("  -> The chance that these gaps are random noise is less than 5%.")
    else:
        print(f"  - p = {p_boundary:.4f} >= 0.05 -> No statistically significant deviation.")
        print("  -> The memoryless property holds for boundaries (at aggregate level).")
    
    print("\nWICKETS:")
    if p_wicket < 0.05:
        print(f"  * p = {p_wicket:.4f} < 0.05 -> Statistically significant deviation from geometric distribution.")
        print("  -> The memoryless property does NOT hold for wickets (at aggregate level).")
        print("  -> The chance that these gaps are random noise is less than 5%.")
    else:
        print(f"  - p = {p_wicket:.4f} >= 0.05 -> No statistically significant deviation.")
        print("  -> The memoryless property holds for wickets (at aggregate level).")
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"BOUNDARIES: p = {p_boundary:.4f} -> {'REJECTS' if p_boundary < 0.05 else 'FAILS TO REJECT'} geometric model")
    print(f"WICKETS:   p = {p_wicket:.4f} -> {'REJECTS' if p_wicket < 0.05 else 'FAILS TO REJECT'} geometric model")
    print("\nNote: This formal test confirms whether the observed deviations are statistically significant.")
    print("      The 'diagnostic' above is a visual/comparative tool; the p-value is the definitive test.")


if __name__ == "__main__":
    main()