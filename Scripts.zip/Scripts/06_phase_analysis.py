import pandas as pd
import matplotlib.pyplot as plt
from common import OUTPUT_TABLES, OUTPUT_FIGURES

def main():
    # Load prepared legal deliveries (output of step 01)
    legal_df = pd.read_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv")
    
    # Ensure boolean columns (already booleans, but safe cast)
    legal_df['is_wicket'] = legal_df['is_wicket'].astype(bool)
    legal_df['is_boundary'] = legal_df['is_boundary'].astype(bool)
    
    # Phase column (already present as 'overs_category')
    legal_df['phase'] = legal_df['overs_category']
    
    # Aggregate by phase
    phase_stats = legal_df.groupby('phase').agg(
        legal_balls=('is_legal_delivery', 'size'),
        wickets=('is_wicket', 'sum'),
        boundaries=('is_boundary', 'sum')
    ).reset_index()
    
    phase_stats['p_wicket'] = phase_stats['wickets'] / phase_stats['legal_balls']
    phase_stats['p_boundary'] = phase_stats['boundaries'] / phase_stats['legal_balls']
    
    # Order phases logically
    phase_order = ['power_play', 'middle_over', 'death_over']
    phase_stats['phase'] = pd.Categorical(phase_stats['phase'], categories=phase_order, ordered=True)
    phase_stats = phase_stats.sort_values('phase')
    
    # Save table
    phase_stats.to_csv(OUTPUT_TABLES / "phase_probabilities.csv", index=False)
    
    # Print summary (exactly as in notebook)
    print("=== PHASE-WISE PROBABILITIES ===")
    print(phase_stats[['phase', 'legal_balls', 'p_wicket', 'p_boundary']].to_string(index=False))
    
    # Create and save the bar plot (matches notebook)
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].bar(phase_stats['phase'], phase_stats['p_wicket'], color='skyblue')
    ax[0].set_title('Wicket probability by phase')
    ax[0].set_ylabel('p_wicket')
    ax[1].bar(phase_stats['phase'], phase_stats['p_boundary'], color='lightcoral')
    ax[1].set_title('Boundary probability by phase')
    ax[1].set_ylabel('p_boundary')
    plt.tight_layout()
    plt.savefig(OUTPUT_FIGURES / "phase_probabilities.png", dpi=150)
    plt.close()

if __name__ == "__main__":
    main()