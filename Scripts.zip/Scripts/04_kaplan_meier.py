import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter
from common import OUTPUT_TABLES, OUTPUT_FIGURES

def main():
    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")
    km_w = KaplanMeierFitter()
    km_b = KaplanMeierFitter()

    km_w.fit(innings_df.first_wicket_attempt, innings_df.first_wicket_event, label="First wicket")
    km_b.fit(innings_df.first_boundary_attempt, innings_df.first_boundary_event, label="First boundary")

    w = km_w.survival_function_.reset_index()
    w.columns = ["legal_deliveries", "survival_probability"]
    w.to_csv(OUTPUT_TABLES / "km_first_wicket_survival.csv", index=False)

    b = km_b.survival_function_.reset_index()
    b.columns = ["legal_deliveries", "survival_probability"]
    b.to_csv(OUTPUT_TABLES / "km_first_boundary_survival.csv", index=False)

    plt.figure(figsize=(9, 6))
    km_w.plot_survival_function(ci_show=True)
    km_b.plot_survival_function(ci_show=True)
    plt.xlabel("Legal deliveries since innings start")
    plt.ylabel("Probability of no event yet")
    plt.title("Kaplan–Meier Survival Curves")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(OUTPUT_FIGURES / "kaplan_meier_wicket_boundary.png", dpi=300)
    plt.close()

    print("=== KAPLAN–MEIER ===")
    print("Median first wicket:", km_w.median_survival_time_)
    print("Median first boundary:", km_b.median_survival_time_)

if __name__ == "__main__":
    main()
