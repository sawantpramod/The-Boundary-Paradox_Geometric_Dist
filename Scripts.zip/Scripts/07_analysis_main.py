import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter
from pathlib import Path

def main():
    # ================================
    # CONFIGURATION – adjust these paths
    # ================================
    DATA_FILE = Path(r"C:\Users\admin\OneDrive\Desktop\Medium.Com\M1\Geometric distribution\Reproducible\data\data-ball_by_ball.csv")
    OUTPUT_TABLES = Path("tables")      # where CSVs will be saved
    OUTPUT_FIGURES = Path("figures")    # where plots will be saved

    # Create output directories if they don't exist
    OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)
    OUTPUT_FIGURES.mkdir(parents=True, exist_ok=True)

    # ================================
    # 1. LOAD AND PREPARE DATA
    # ================================
    df = pd.read_csv(DATA_FILE)
    df['is_legal_delivery'] = df['is_legal_delivery'].astype(bool)
    df['wicket_flag'] = df['wicket_flag'].astype(bool)

    legal_df = df[df['is_legal_delivery']].copy()
    legal_df['is_wicket'] = legal_df['wicket_flag']
    legal_df['is_boundary'] = legal_df['runs_off_bat'] >= 4   # 4 or 6

    # Save the legal deliveries for later use (e.g., phase analysis)
    legal_df.to_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv", index=False)
    print(f"Saved legal deliveries: {OUTPUT_TABLES / 'legal_deliveries_prepared.csv'}")

    # ================================
    # 2. BUILD INNINGS-LEVEL DATASET
    # ================================
    def first_attempt_and_censored(group, success_col):
        """Return (first_success_ball, event_observed) for a group."""
        success_indices = group[success_col].values.nonzero()[0]
        if len(success_indices) > 0:
            first_idx = success_indices[0] + 1   # 1‑based index
            event_obs = 1
        else:
            first_idx = len(group)               # censored at last ball
            event_obs = 0
        return first_idx, event_obs

    grouped = legal_df.groupby(['match_id', 'innings_no'])
    records = []
    for (match, innings), group in grouped:
        batting_team = group['batting_team'].iloc[0] if 'batting_team' in group.columns else None
        w_attempt, w_event = first_attempt_and_censored(group, 'is_wicket')
        b_attempt, b_event = first_attempt_and_censored(group, 'is_boundary')
        records.append({
            'match_id': match,
            'innings_no': innings,
            'batting_team': batting_team,
            'first_wicket_attempt': w_attempt,
            'first_wicket_event': w_event,
            'first_boundary_attempt': b_attempt,
            'first_boundary_event': b_event,
            'total_legal_deliveries': len(group)
        })
    innings_df = pd.DataFrame(records)

    # Save the innings dataset
    innings_df.to_csv(OUTPUT_TABLES / "innings_survival_dataset.csv", index=False)
    print(f"Saved innings dataset: {OUTPUT_TABLES / 'innings_survival_dataset.csv'}")

    # ================================
    # 3. BASELINE PROBABILITIES & THEORETICAL MEANS
    # ================================
    total_legal = legal_df.shape[0]
    total_wickets = legal_df['is_wicket'].sum()
    total_boundaries = legal_df['is_boundary'].sum()

    p_wicket = total_wickets / total_legal
    p_boundary = total_boundaries / total_legal

    # Save baseline summary
    baseline_df = pd.DataFrame([
        {'event': 'First wicket', 'p_hat': p_wicket, 'theoretical_mean': 1/p_wicket},
        {'event': 'First boundary', 'p_hat': p_boundary, 'theoretical_mean': 1/p_boundary}
    ])
    baseline_df.to_csv(OUTPUT_TABLES / "geometric_baseline_summary.csv", index=False)

    print("\n=== BASELINE PROBABILITIES ===")
    print(f"p_wicket   = {p_wicket:.4f}  (1/p = {1/p_wicket:.2f})")
    print(f"p_boundary = {p_boundary:.4f}  (1/p = {1/p_boundary:.2f})")

    # ================================
    # 4. EMPIRICAL MEANS (UNCENSORED ONLY)
    # ================================
    unc_w = innings_df[innings_df['first_wicket_event'] == 1]['first_wicket_attempt']
    unc_b = innings_df[innings_df['first_boundary_event'] == 1]['first_boundary_attempt']

    mean_wicket_obs = unc_w.mean()
    mean_boundary_obs = unc_b.mean()

    print("\n=== EMPIRICAL FIRST-EVENT MEANS (uncensored) ===")
    print(f"Mean balls to first wicket   = {mean_wicket_obs:.2f}  (vs theoretical {1/p_wicket:.2f})")
    print(f"Mean balls to first boundary = {mean_boundary_obs:.2f}  (vs theoretical {1/p_boundary:.2f})")

    # ================================
    # 5. KAPLAN‑MEIER SURVIVAL CURVES
    # ================================
    kmf_wicket = KaplanMeierFitter()
    kmf_wicket.fit(innings_df['first_wicket_attempt'],
                   event_observed=innings_df['first_wicket_event'],
                   label='First wicket')

    kmf_boundary = KaplanMeierFitter()
    kmf_boundary.fit(innings_df['first_boundary_attempt'],
                     event_observed=innings_df['first_boundary_event'],
                     label='First boundary')

    # Save survival tables
    def save_km_table(kmf, filename):
        surv = kmf.survival_function_.reset_index()
        surv.columns = ['legal_deliveries', 'survival_probability']
        surv.to_csv(OUTPUT_TABLES / filename, index=False)

    save_km_table(kmf_wicket, "km_first_wicket_survival.csv")
    save_km_table(kmf_boundary, "km_first_boundary_survival.csv")

    # Plot both curves
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    kmf_wicket.plot_survival_function(ax=axes[0])
    axes[0].set_title('Survival: time to first wicket')
    axes[0].set_xlabel('Legal deliveries')
    axes[0].set_ylabel('Survival probability')

    kmf_boundary.plot_survival_function(ax=axes[1])
    axes[1].set_title('Survival: time to first boundary')
    axes[1].set_xlabel('Legal deliveries')
    axes[1].set_ylabel('Survival probability')

    plt.tight_layout()
    plt.savefig(OUTPUT_FIGURES / "survival_curves.png", dpi=150)
    plt.show()

    print("\n=== KAPLAN-MEIER MEDIANS ===")   # <-- fixed hyphen
    print(f"Median first wicket:   {kmf_wicket.median_survival_time_}")
    print(f"Median first boundary: {kmf_boundary.median_survival_time_}")

    print("\nAll outputs saved successfully.")

if __name__ == "__main__":
    main()