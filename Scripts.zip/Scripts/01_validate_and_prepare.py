from common import DATA_FILE, OUTPUT_TABLES, load_data, prepare_analysis_view, file_sha256, log

def main():
    df = load_data()
    legal = prepare_analysis_view(df)

    # Save an enriched ALL-DELIVERY file: same number of rows as raw data.
    # This is not a replacement for the raw CSV.
    enriched = df.copy()
    enriched["is_wicket_for_analysis"] = enriched["wicket_flag"]
    enriched["is_boundary_for_analysis"] = (
        enriched["is_legal_delivery"] & enriched["runs_off_bat"].isin([4, 6])
    )
    enriched.to_csv(OUTPUT_TABLES / "ball_by_ball_enriched_all_rows.csv", index=False)

    validation = {
        "raw_rows": len(df),
        "raw_columns": df.shape[1],
        "legal_delivery_rows": len(legal),
        "non_legal_rows": int((~df["is_legal_delivery"]).sum()),
        "raw_wicket_rows": int(df["wicket_flag"].sum()),
        "legal_wicket_rows": int((df["is_legal_delivery"] & df["wicket_flag"]).sum()),
        "non_legal_wicket_rows": int((~df["is_legal_delivery"] & df["wicket_flag"]).sum()),
        "legal_boundary_rows": int(legal["is_boundary"].sum()),
        "matches": int(df["match_id"].nunique()),
        "innings": int(df[["match_id", "innings_no"]].drop_duplicates().shape[0]),
        "raw_sha256": file_sha256(DATA_FILE),
    }
    import pandas as pd
    pd.DataFrame([validation]).to_csv(
        OUTPUT_TABLES / "data_validation_summary.csv", index=False
    )

    # Integrity assertion: derived file must preserve every raw row.
    assert len(enriched) == len(df)
    assert enriched.columns[:df.shape[1]].tolist() == df.columns.tolist()

    # Legal-only file is explicitly derived; raw data remains untouched.
    legal.to_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv", index=False)

    print("=== DATA VALIDATION / INTEGRITY ===")
    for k, v in validation.items():
        print(f"{k}: {v}")
    print(f"Saved ALL rows: {OUTPUT_TABLES / 'ball_by_ball_enriched_all_rows.csv'}")
    print(f"Saved legal-delivery analysis view: {OUTPUT_TABLES / 'legal_deliveries_prepared.csv'}")
    print("RAW DATA IS NOT DELETED OR OVERWRITTEN.")
    log(f"Validation completed. Raw rows={len(df)}, legal rows={len(legal)}, sha256={validation['raw_sha256']}")

if __name__ == "__main__":
    main()
