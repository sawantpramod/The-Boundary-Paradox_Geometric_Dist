import subprocess
import sys
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"

scripts = [
    "01_validate_and_prepare.py",
    "02_build_innings.py",
    "03_geometric_baseline.py",
    "04_kaplan_meier.py",
    "05_memoryless_property.py",
    "06_phase_analysis.py",
    "07_first_event_phase_distribution.py"
]

log = ROOT / "logs" / "run_log.txt"
log.parent.mkdir(parents=True, exist_ok=True)

with open(log, "a", encoding="utf-8") as f:
    f.write("\n" + "="*80 + f"\nRUN {datetime.now().isoformat()}\n")

for script in scripts:
    print("\n" + "="*80)
    print(f"RUNNING {script}")
    print("="*80)
    result = subprocess.run([sys.executable, str(SRC / script)], cwd=str(SRC))
    if result.returncode != 0:
        raise SystemExit(f"Pipeline stopped because {script} failed (exit code {result.returncode}).")

print("\n" + "="*80)
print("PIPELINE COMPLETED SUCCESSFULLY")
print("Raw data was never overwritten or deleted.")
print("="*80)
